package com.example.chargingPileSystem.constant;

public class ChargingPileRecordConstant {
    public static final int ORDER_UNACCOMPLISHED = 0;//订单未完成
    public static final int ORDER_ACCOMPLISHED = 1;//订单已完成
}
