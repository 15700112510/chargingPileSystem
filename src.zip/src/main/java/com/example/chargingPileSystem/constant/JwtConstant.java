package com.example.chargingPileSystem.constant;


public class JwtConstant {

//    jwt密钥
    public static final String SECRET = "8812zeddyyznm82819001hnd9121";


    public static final int INVALID_TOKEN_TTL = 0;

//    有效token的ttl
    public static final int VALID_TOKEN_TTL = 30 * 60 * 1000;

}
