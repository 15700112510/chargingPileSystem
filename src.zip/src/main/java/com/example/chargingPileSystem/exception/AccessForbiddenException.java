package com.example.chargingPileSystem.exception;

public class AccessForbiddenException extends RuntimeException {

}
