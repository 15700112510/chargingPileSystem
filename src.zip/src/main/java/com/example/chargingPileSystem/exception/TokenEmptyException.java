package com.example.chargingPileSystem.exception;

//令牌为空异常
public class TokenEmptyException extends RuntimeException{
}
