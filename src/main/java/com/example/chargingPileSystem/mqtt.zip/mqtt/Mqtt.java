package com.example.chargingPileSystem.mqtt;


//@Component
public class Mqtt {

}
