package com.example.chargingPileSystem.mqtt;

public interface MsgProcessor {
    public void process();
}
